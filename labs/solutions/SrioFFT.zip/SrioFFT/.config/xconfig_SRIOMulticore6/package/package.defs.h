/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-x14
 */

#ifndef xconfig_SRIOMulticore6__
#define xconfig_SRIOMulticore6__



#endif /* xconfig_SRIOMulticore6__ */ 

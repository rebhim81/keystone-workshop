/*
 * requestProcessingData.c
 *
 *  Created on: Sep 12, 2011  idx  0xff
 *      Author: a0270985
 */
#include <requestProcessingData.h>
#include <masterTask.h>
#include <initialization.h>

/* Bios Files */
#include <xdc/runtime/System.h>

/* System Trace Library */
#include <system_trace.h>


extern STMHandle *pSTMHandle;

/*
 * File Level Globals
 */
int32_t	messageSource;

/*
 * Extern Variables
 */
extern uint32_t 				coreNum;
extern uint16_t 				coreDeviceID[NUM_CORES_MAX];
extern Srio_SockHandle			srioSocket;
extern int16_t*					txData_int;
extern Srio_SockAddrInfo		to;
extern Srio_SockAddrInfo		from;
extern int32_t					sendToCore;
extern Srio_DrvBuffer			hDrvBuffer;
extern int32_t 					coreLoop;
extern int32_t 					firstSendStart;




void freeBuffer(short * in, bufferControl_t control[])
{
	int  i   ;
	if (in == NULL ) return   ;
	for (i=0; i<NUM_FFT_BUFFER; i++)
	{
		if (control[i].pointer == in)
		{
			control[i].status = FREE_BUFFER   ;
			return  ;
		}

	}
#if (VERBOSE_LEVEL > 1)
	System_printf("error in free buffer \n")  ;
#endif
	return ;
}



int requestProcessingData(short *buffer, int N)
{
	int32_t num_bytes;
	uint8_t* ptr_rxDataPayload;
	int16_t *ppp;
	int32_t tokenFlag;

	STMXport_logMsg0(pSTMHandle, STMC_CLEAR_BUFFER, "Clearing Buffer");
	while((num_bytes = Srio_sockRecv (srioSocket, (Srio_DrvBuffer*)&ptr_rxDataPayload, &from)) != 0)
	{
		Srio_freeRxDrvBuffer(srioSocket, (Srio_DrvBuffer)ptr_rxDataPayload);
	}


           for (coreLoop=firstSendStart; coreLoop<NUM_CORES; coreLoop++)
           {
                  sendToCore   =  CORE_SYS_INIT + coreLoop ;
                  txData_int[0] = coreLoop * 17 ;
                  txData_int[1] = N ;
                  to.type11.id       = coreDeviceID[sendToCore];
                  if (Srio_sockSend (srioSocket, hDrvBuffer, SEND_SIZE, &to) < 0)
                  {
#if (VERBOSE_LEVEL > 1)
                   System_printf ("Error: SRIO Socket send failed\n");
#endif
                   return -1;
                  }

                 ranDelay(3)  ;
          }//  for
          STMXport_logMsg0(pSTMHandle, STMC_M_REQUEST_PROCESSING, "Process Request sent to all cores\0");
          firstSendStart = 1  ;

           tokenFlag = 0   ;
 //////////////////////////////////////////////
 ////         Step 4 - read the first message and send TOKEN to the core
           while (tokenFlag == 0)  //  wait to get READY from someone
           {
                   while ((num_bytes = Srio_sockRecv (srioSocket, (Srio_DrvBuffer*)&ptr_rxDataPayload, &from))==0)
                   {
                   }

                                 //    A message was received
                   if (num_bytes > 0)
                   {
                	   messageSource = from.type11.id ;
                	   ppp = (short *)&ptr_rxDataPayload[0] ;

 //            	     System_printf("has  message from core %d with address %x \n",
 //            	    		 coreNumberFromId(coreDeviceID,from.type11.id), *ppp);
             	     if ( *ppp == READY)  tokenFlag = 1   ;
             	     STMXport_logMsg1(pSTMHandle, STMC_S_READY, "Agree to process by Core %d\n", coreNumberFromId(&coreDeviceID[0], from.type11.id));
                     Srio_freeRxDrvBuffer(srioSocket, (Srio_DrvBuffer)ptr_rxDataPayload);
                   }
           }
           ranDelay(30)  ;   //   Ran Katzur Special Delay
//           txData_int[0] = TOKEN ;
//           txData_int[1] = N ;
 //          printStartEnd(buffer, 2*N)  ;
           buffer[1] = buffer[0]   ;
           buffer[0] = TOKEN   ;
           memcpy(txData_int, buffer,4*N)  ;
                          sendToCore   = coreNumberFromId(&coreDeviceID[0], messageSource);
 //                                       System_printf("TOKEN  to core %d with N = %d and buffer = %x  \n",
//                                      		sendToCore, N, buffer	 );
//          System_printf("TOKEN  to core %d with N = %d   \n", sendToCore, N	 );
                                        /* Send the data out. */
          to.type11.id       = coreDeviceID[sendToCore];
          if (N < 128) N = 128 ; // segmentation socket must have more than 256 bytes
          if (Srio_sockSend (srioSocket, hDrvBuffer, 4*N, &to) < 0)
          {
#if (VERBOSE_LEVEL > 1)
        	  System_printf ("Error: SRIO Socket send failed\n");
#endif
        	  return -1;
          }
          STMXport_logMsg1(pSTMHandle, STMC_M_SENT_DATA, "Data Sent to Core %d\n", sendToCore);
          return (0) ;
}

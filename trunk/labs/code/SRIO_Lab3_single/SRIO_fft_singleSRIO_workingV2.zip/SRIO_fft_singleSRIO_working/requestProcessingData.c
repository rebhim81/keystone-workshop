/*
 * requestProcessingData.c
 *
 *  Created on: Sep 12, 2011  idx  0xff
 *      Author: a0270985
 */

#include "bioInclude.h"

void freeBuffer(short * in, bufferControl_t control[])
{
	int  i   ;
	if (in == NULL ) return   ;
	for (i=0; i<NUM_FFT_BUFFER; i++)
	{
		if (control[i].pointer == in)
		{
			control[i].status = FREE_BUFFER   ;
			return  ;
		}

	}
	System_printf("error in free buffer \n")  ;
	return ;
}



int requestProcessingData(short *buffer, int N)
{
          short *ppp   ;
          int tokenFlag   ;
          while((num_bytes = Srio_sockRecv (srioSocket, (Srio_DrvBuffer*)&ptr_rxDataPayload, &from)) != 0)
            {


 //       	     System_printf("ignore message from core %d \n", coreNumberFromId(coreDeviceID,from.type11.id));
                 Srio_freeRxDrvBuffer(srioSocket, (Srio_DrvBuffer)ptr_rxDataPayload);
            }
 ////////////////////////////////////////////////////////////////////////////
           //  step  2
  //         System_printf ( "got Data  -->  send requests  \n");

           for (coreLoop=firstSendStart; coreLoop<NUM_CORES; coreLoop++)
//              for (coreLoop=firstSendStart; coreLoop<firstSendStart+1; coreLoop++)

           {
                  sendToCore   =  CORE_SYS_INIT + coreLoop ;
                  txData_int[0] = coreLoop * 17 ;
                  txData_int[1] = N ;
                  to.type11.id       = coreDeviceID[sendToCore];
                  if (Srio_sockSend (srioSocket, hDrvBuffer, SEND_SIZE, &to) < 0)
                  {
                   System_printf ("Error: SRIO Socket send failed\n");
                   return -1;
                  }
 //                  System_printf("send request to core %d \n", coreNumberFromId(coreDeviceID,to.type11.id));
                 ranDelay(3)  ;
          }//  for
          firstSendStart = 1  ;

           tokenFlag = 0   ;
 //////////////////////////////////////////////
 ////         Step 4 - read the first message and send TOKEN to the core
           while (tokenFlag == 0)  //  wait to get READY from someone
           {
                   while ((num_bytes = Srio_sockRecv (srioSocket, (Srio_DrvBuffer*)&ptr_rxDataPayload, &from))==0)
                   {
                   }
                                 //    A message was received
                   if (num_bytes > 0)
                   {
                          messageSource = from.type11.id ;
                          ppp = (short *)&ptr_rxDataPayload[0] ;

 //            	     System_printf("has  message from core %d with address %x \n",
 //            	    		 coreNumberFromId(coreDeviceID,from.type11.id), *ppp);
             	     if ( *ppp == READY)  tokenFlag = 1   ;
                     Srio_freeRxDrvBuffer(srioSocket, (Srio_DrvBuffer)ptr_rxDataPayload);
                   }
           }
           ranDelay(30)  ;   //   Ran Katzur Special Delay
//           txData_int[0] = TOKEN ;
//           txData_int[1] = N ;
 //          printStartEnd(buffer, 2*N)  ;
           buffer[1] = buffer[0]   ;
           buffer[0] = TOKEN   ;
           memcpy(txData_int, buffer,4*N)  ;
                          sendToCore   = coreNumberFromId(coreDeviceID, messageSource);
 //                                       System_printf("TOKEN  to core %d with N = %d and buffer = %x  \n",
//                                      		sendToCore, N, buffer	 );
//          System_printf("TOKEN  to core %d with N = %d   \n", sendToCore, N	 );
                                        /* Send the data out. */
          to.type11.id       = coreDeviceID[sendToCore];
          if (N < 128) N = 128 ; // segmentation socket must have more than 256 bytes
          if (Srio_sockSend (srioSocket, hDrvBuffer, 4*N, &to) < 0)
                         {
                                    System_printf ("Error: SRIO Socket send failed\n");
                                    return -1;
                         }



      return (0) ;
}

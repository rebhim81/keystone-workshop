/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-y25
 */

#ifndef xconfig_SRIOMulticore_fft_1__
#define xconfig_SRIOMulticore_fft_1__



#endif /* xconfig_SRIOMulticore_fft_1__ */ 

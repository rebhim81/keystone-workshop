

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <time.h>

#include <stdio.h>
#include "c6x.h"


#include "utilities.h"


/**************************************************************************
 *
 * This file contains a list of function that helps in multi-cores operation
 *
 * The first set of functions provides a barrier point, that is, a point that
 * core waits until all cores that participate in the algorithm reach that point
 *
 * To build the barrier point we need first to have some array in the shared memory
 * and of course we cannot use cache.  So here are two methods:
 * 1. Have the array in a non-cacheable memory, or
 * 2. Invalidate the cache every time read is done and write back every write
 *
 *
 * To make things easier I chose the second option
 *
 * The Algorithm:
 *
 * The variable number_of_cores is a global variable that enable to adapt the system for 4 cores
 * or 8 cores. Further development can modify it into a core binary participation, namely, we can
 * configure each core to participate or not in the barrier
 * Important - since we may want to have multiple barriers, this is not a real global variable but an instance
 * of the barrier function
 *
 * A vector XX of type int has 8 elements. These elements are set to 0 during initialization
 *
 * A "setNumberOfCores routine tells the instance how many cores participate in the barrier. remember, in this point
 * the cores are always start at core0 and go on. Later we can modify this routine to be able
 * to select participates as needed.  The default value of the number of cores is 8
 *
 * When a core reaches a barrier point it does the following:
 * First it write 1 in his location of the vector XX and does cache invalidate write back
 * Next it reads all elements of the vector in a look, invalidate cache before each read until all of them are 1
 * then it return from the routine
 *
 * In order to have another barrier, one or more cores should call the function resetBarrier. This function
 * reset all the xx elements to zero again
 *
 * BarrirDisable set all elements of the vector to 1
 *
 *
 * Ran Katzur      10/17/13
 *
 *
 *
 */

int waitAboutNSeconds(int N)
{
	volatile int yy    ;
    int  i   ;
    yy = 0   ;
    for (i=0; i<N*10; i++)
    {
    	yy = yy + waitAboutSecond()   ;
    }
	return 0 ;

}



void initJoinPoint(int * point)
{

	CSL_semAcquireIndirect (SEMAPHORE_NUMBER);
	*point = 0  ;
	CSL_semReleaseSemaphore (SEMAPHORE_NUMBER);
}

void joinPoint(int * point)
{
	volatile int x, flag  ;
	CSL_semAcquireIndirect (SEMAPHORE_NUMBER);

	if (*point  == NUMBER_OF_CORES ) *point = 0  ;
	*point = *point + 1   ;
	CSL_semReleaseSemaphore (SEMAPHORE_NUMBER);
	flag = 0  ;
	while (flag == 0)
	{
		CSL_semAcquireIndirect (SEMAPHORE_NUMBER);
		if (*point == NUMBER_OF_CORES) flag = 1 ;
		CSL_semReleaseSemaphore (SEMAPHORE_NUMBER);
		waitAboutNSeconds(5);

	}


}


void setNumberOfCores(barrier_t *barrier, int Number)
{
	//  Default value is 8

	barrier->numberOfCores = Number  ;
//	CACHE_wbInvL1d(&barrier->numberOfCores, 128,CACHE_FENCE_WAIT)   ;
//	CACHE_wbInvL2(&barrier->numberOfCores, 128, CACHE_FENCE_WAIT)   ;
	return ;
}


int waitAboutSecond(void)
{
	volatile int xx    ;
	int i  ;
	xx = 1   ;
	for (i=0; i<10000; i++)
	{
		xx = xx + 1    ;
	}
	xx = xx / (i-1) ;
	return (xx);
}




void resetBariier(barrier_t *barrier)
{
	//reset all values to 0
	int   i   ;



	waitAboutNSeconds(20);
	for (i=0; i< barrier->numberOfCores; i++)
	{
		barrier->xx[i] = 0  ;
	}

	waitAboutNSeconds(20);
//	CACHE_wbInvL1d(barrier, sizeof(barrier_t),CACHE_FENCE_WAIT)   ;
//	CACHE_wbInvL2(barrier, sizeof(barrier_t), CACHE_FENCE_WAIT)   ;


//	System_printf("reset barrier  \n")  ;
}

void waitBarrier(barrier_t *barrier, int coreNum, int Value)
{
	int i   ;
	volatile int flag  ;
	volatile int  x   ;
	int *p1  ;



	p1 = (int *) &(barrier->xx[coreNum])  ;
	*p1 = Value  ;

	flag = 0  ;
	while (flag == 0)
	{
		flag = 1  ;


		for (i=0; i<NUMBER_OF_CORES; i++)
		{
			x = barrier->xx[i]  ;
			if (x !=  Value )   flag = 0   ;
		}

	}
	waitAboutNSeconds(10);


}


float   myMultiply(float x, float  y)


{
	return (x*y);
}







/*
 * firMain.c
 *
 *  The project FIT_filter runs on the C66 cores of the 66AK2H6638 devices
 *
 */

#include <stdio.h>
#include "firTest.h"
#include "utilities.h"
//   Define and allocate the data and the filter coefficients

#pragma DATA_SECTION (inputData, ".DDR3")
#pragma DATA_ALIGN (inputData,8)
float inputData[NUMBER_OF_ELEMENTS];


#pragma DATA_SECTION (outputFilter, ".DDR3")
#pragma DATA_ALIGN (outputFilter,0x10000000)
float outputFilter[NUMBER_OF_FILTERS][NUMBER_OF_ELEMENTS];


#pragma DATA_SECTION (filterCoef, ".DDR3")
#pragma DATA_ALIGN (filterCoef,8)
float filterCoef[NUMBER_OF_FILTERS][FILTER_SIZE];



barrier_t *barrier_1;
int  *sem_point   ;


#define  CASE_1
#define  CASE_2
#define  CASE_3
#define  CASE_4

#define   CASE_5




//************************************************************************
void main()
{

	int loop_filters ,coreNum ;

    volatile int waitFlag = 1  ;
    volatile int  vi  ;

	volatile int jointNumber  ;


   float  diffTime1  , diffTime2 , xxx  ;

    unsigned long     t1, t2,t1H, t2H    ;
    int valueForPrintInteger  ;


    /* Reset timer */
    TSCL = 0;
	t1 = TSCL   ;
	t1H = TSCH  ;
	t2 = TSCL   ;
	t2H = TSCH  ;
	diffTime1 = ((long long) (t2H - t1H)) * 0x0100000000 + (long long)(t2-t1)    ;

    jointNumber = 1  ;


       CACHE_disableCaching ((Uint8) 144)    ;
       CACHE_disableCaching ((Uint8) 136)    ;
       CACHE_disableCaching ((Uint8) 147)    ;
       CACHE_disableCaching ((Uint8) 145)    ;
       CACHE_disableCaching ((Uint8) 146)    ;
       CACHE_disableCaching ((Uint8) 128)    ;
//  Disable the cache-ability of the DDR and generate the data
//  All arrays were defined in the beginning of the DDR
//   MAR register number 128 controls the 16MB memory starts at 0x8000 0000
//   All our data less than  (5 * 4 * NUMBER_OF_ELEMENTS * (NUMBER_OF_FILTERS+1) )
//   and is less than 16M
//   From the CSL library use the function


//  Generate the filter coefficients  - only core 0

	coreNum = CSL_chipReadReg (CSL_CHIP_DNUM);
	barrier_1 = (barrier_t *)  0x88000000   ;

	if (coreNum == 0)
	{


        System_printf(" start generating input data  \n")  ;
		generateRandomFloatData(inputData, NUMBER_OF_ELEMENTS, MIN_INPUT, MAX_INPUT);
        System_printf(" finish generating input data  \n")  ;
		for (loop_filters = 0; loop_filters < NUMBER_OF_FILTERS; loop_filters++)
		{
			generateLimitedSumRandomFloatData(&filterCoef[loop_filters][0], FILTER_SIZE, FILTER_SUM)  ;
//			System_printf(" finish with filter %d  \n", loop_filters);
		}
		CACHE_wbInvAllL1dWait() ;
		CACHE_wbInvL2Wait() ;


	}




////   Case 1   -  single core, disable cache (L2 and L1)
#ifdef   CASE_1



    if (coreNum == 0)
    {
    	t1 = TSCL   ;
    	t1H = TSCH  ;
    	for (loop_filters = 0; loop_filters < NUMBER_OF_FILTERS; loop_filters++)
    	{
    	     firRealFilter(&inputData[(coreNum * LOOP_1_FIRST)],
    			         &filterCoef[loop_filters][0], LOOP_1_LAST, FILTER_SIZE,
    			            &outputFilter[loop_filters][coreNum * LOOP_1_FIRST] ) ;
    	}

    	t2 = TSCL   ;
    	t2H = TSCH  ;
    	diffTime2 = ((float)(t2H - t1H)) * 0x0100000000 + (float)(t2-t1)    ;
    	xxx = diffTime2 - diffTime1   ;

    	valueForPrintInteger = (int) xxx   ;
    	System_printf("case 1 ->  time consumed By core -> %d %d   \n",coreNum, valueForPrintInteger );

    }

#endif






	////   Case 2   -  single core, enable cache (L2 and L1)  but a single core
#ifdef   CASE_2

    CACHE_setL2Size ((CACHE_L2Size) 4);
    CACHE_enableCaching ((Uint8) 128)    ;
    CACHE_invAllL1dWait ();
    CACHE_invAllL2Wait ();

	    if (coreNum == 0)
	    {
	    	t1 = TSCL   ;
	    	t1H = TSCH  ;
	    	for (loop_filters = 0; loop_filters < NUMBER_OF_FILTERS; loop_filters++)
	    	{
	    	     firRealFilter(&inputData[(coreNum * LOOP_1_FIRST)],
	    			         &filterCoef[loop_filters][0], LOOP_1_LAST, FILTER_SIZE,
	    			            &outputFilter[loop_filters][coreNum * LOOP_1_FIRST] ) ;
	    	}
	    	t2 = TSCL   ;
	    	t2H = TSCH  ;
	       	diffTime2 = ((float)(t2H - t1H)) * 0x0100000000 + (float)(t2-t1)    ;
	        	xxx = diffTime2 - diffTime1   ;

	        	valueForPrintInteger = (int) xxx   ;
	        	System_printf("case 2 ->  time consumed By core -> %d %d   \n",coreNum, valueForPrintInteger );

	    }

#endif

		////   Case 3   -  2 cores, enable cache (L2 and L1)
#ifdef   CASE_3
           CACHE_enableCaching ((Uint8) 128)    ;
           CACHE_invAllL1dWait ();
           CACHE_invAllL2Wait ();
//			waitBarrier(barrier_1, coreNum, jointNumber)   ;
			jointNumber = 2  ;

//			resetBariier(barrier_1) ;
//           joinPoint (sem_point) ;



		    if (coreNum == 0)
		    {
		    	t1 = TSCL   ;
		    	t1H = TSCH  ;
		    	for (loop_filters = 0; loop_filters < NUMBER_OF_FILTERS; loop_filters++)
		    	{
		    	     firRealFilter(&inputData[(coreNum * LOOP_2_FIRST)],
		    			         &filterCoef[loop_filters][0], LOOP_2_FIRST, FILTER_SIZE,
		    			            &outputFilter[loop_filters][coreNum * LOOP_2_FIRST] ) ;
		    	}
		    	t2 = TSCL   ;
		    	t2H = TSCH  ;
		       	diffTime2 = ((float)(t2H - t1H)) * 0x0100000000 + (float)(t2-t1)    ;
		        	xxx = diffTime2 - diffTime1   ;
		        	valueForPrintInteger = (int) xxx   ;
		        	System_printf("case 3 ->  time consumed By core -> %d %d   \n",coreNum, valueForPrintInteger );
		    }

		    	 if (coreNum == 1)
		         {
				    	t1 = TSCL   ;
				    	t1H = TSCH  ;
		           for (loop_filters = 0; loop_filters < NUMBER_OF_FILTERS; loop_filters++)
		    	   {
		    	     firRealFilter(&inputData[(coreNum * LOOP_2_FIRST)],
		    			         &filterCoef[loop_filters][0], LOOP_2_LAST, FILTER_SIZE,
		    			            &outputFilter[loop_filters][coreNum * LOOP_2_FIRST] ) ;
		           }
			    	t2 = TSCL   ;
			    	t2H = TSCH  ;
			       	diffTime2 = ((float)(t2H - t1H)) * 0x0100000000 + (float)(t2-t1)    ;
			        	xxx = diffTime2 - diffTime1   ;
			        	valueForPrintInteger = (int) xxx   ;
			        	System_printf("case 3 ->  time consumed By core -> %d %d   \n",coreNum, valueForPrintInteger );



		         }


//	CACHE_InvAllL1dWait() ;
//	CACHE_wbInvL2Wait() ;


#endif

			////   Case 4   -  4 cores, enable cache (L2 and L1)
#ifdef   CASE_4
	              CACHE_enableCaching ((Uint8) 128)    ;
	              CACHE_invAllL1dWait ();
	              CACHE_invAllL2Wait ();
//					waitBarrier(barrier_1, coreNum, jointNumber)   ;
					jointNumber = 3  ;


//			    Ipc_start();
			    if (coreNum == 0)
			    {
			    	t1 = TSCL   ;
			    	t1H = TSCH  ;
			    	for (loop_filters = 0; loop_filters < NUMBER_OF_FILTERS; loop_filters++)
			    	{
			    	     firRealFilter(&inputData[(coreNum * LOOP_4_FIRST)],
			    			         &filterCoef[loop_filters][0], LOOP_4_FIRST, FILTER_SIZE,
			    			            &outputFilter[loop_filters][coreNum * LOOP_4_FIRST] ) ;
			    	}
			    	t2 = TSCL   ;
			    	t2H = TSCH  ;
			       	diffTime2 = ((float)(t2H - t1H)) * 0x0100000000 + (float)(t2-t1)    ;
			        	xxx = diffTime2 - diffTime1   ;
			        	valueForPrintInteger = (int) xxx   ;
			        	System_printf("case 4 ->  time consumed By core -> %d %d   \n",coreNum, valueForPrintInteger );
			    }
			    if ( (coreNum == 1) || (coreNum == 2))
			    {


			    	t1 = TSCL   ;
			    	t1H = TSCH  ;
			            for (loop_filters = 0; loop_filters < NUMBER_OF_FILTERS; loop_filters++)
			    	    {
			    	        firRealFilter(&inputData[(coreNum * LOOP_4_FIRST)],
			    			         &filterCoef[loop_filters][0], LOOP_4_FIRST, FILTER_SIZE,
			    			            &outputFilter[loop_filters][coreNum * LOOP_4_FIRST] ) ;
			             }
				    	t2 = TSCL   ;
				    	t2H = TSCH  ;
				       	diffTime2 = ((float)(t2H - t1H)) * 0x0100000000 + (float)(t2-t1)    ;
				        	xxx = diffTime2 - diffTime1   ;
				        	valueForPrintInteger = (int) xxx   ;
				        	System_printf("case 4 ->  time consumed By core -> %d %d   \n",coreNum, valueForPrintInteger );
			        }



			     if (coreNum == 3)
			     {
				    	t1 = TSCL   ;
				    	t1H = TSCH  ;
			         for (loop_filters = 0; loop_filters < NUMBER_OF_FILTERS; loop_filters++)
			    	 {
			    	     firRealFilter(&inputData[(coreNum * LOOP_4_FIRST)],
			    			         &filterCoef[loop_filters][0], LOOP_4_LAST, FILTER_SIZE,
			    			            &outputFilter[loop_filters][coreNum * LOOP_4_FIRST] ) ;
			         }
				    	t2 = TSCL   ;
				    	t2H = TSCH  ;
				       	diffTime2 = ((float)(t2H - t1H)) * 0x0100000000 + (float)(t2-t1)    ;
				        	xxx = diffTime2 - diffTime1   ;
				        	valueForPrintInteger = (int) xxx   ;
				        	System_printf("case 4 ->  time consumed By core -> %d %d   \n",coreNum, valueForPrintInteger );
			     }

					CACHE_wbInvAllL1dWait() ;
					CACHE_wbInvL2Wait() ;


#endif

					////   Case 5   -  8 cores, enable cache (L2 and L1)
#ifdef   CASE_5
		              CACHE_enableCaching ((Uint8) 128)    ;
		              CACHE_invAllL1dWait ();
		              CACHE_invAllL2Wait ();
//						waitBarrier(barrier_1, coreNum, jointNumber)   ;
						jointNumber =4  ;



			    if (coreNum == 0)
				{
			    	t1 = TSCL   ;
				    	t1H = TSCH  ;
					 for (loop_filters = 0; loop_filters < NUMBER_OF_FILTERS; loop_filters++)
					 {
					    	 firRealFilter(&inputData[(coreNum * LOOP_8_FIRST)],
					    			         &filterCoef[loop_filters][0], LOOP_8_FIRST, FILTER_SIZE,
					    			            &outputFilter[loop_filters][coreNum * LOOP_8_FIRST] ) ;
					  }
				    	t2 = TSCL   ;
				    	t2H = TSCH  ;
				       	diffTime2 = ((float)(t2H - t1H)) * 0x0100000000 + (float)(t2-t1)    ;
				        	xxx = diffTime2 - diffTime1   ;
				        	valueForPrintInteger = (int) xxx   ;
				        	System_printf("case 5 ->  time consumed By core -> %d %d   \n",coreNum, valueForPrintInteger );
			    }
			if ( (coreNum == 1) || (coreNum == 2) ||(coreNum == 3) ||
					      (coreNum == 4)||(coreNum == 5) || (coreNum == 6) )
		    {


		    	t1 = TSCL   ;
			    	t1H = TSCH  ;
			    for (loop_filters = 0; loop_filters < NUMBER_OF_FILTERS; loop_filters++)
			    {
					        firRealFilter(&inputData[(coreNum * LOOP_8_FIRST)],
					             &filterCoef[loop_filters][0], LOOP_8_FIRST, FILTER_SIZE,
					             &outputFilter[loop_filters][coreNum * LOOP_8_FIRST] ) ;
			    }
		    	t2 = TSCL   ;
		    	t2H = TSCH  ;
		       	diffTime2 = ((float)(t2H - t1H)) * 0x0100000000 + (float)(t2-t1)    ;
		        	xxx = diffTime2 - diffTime1   ;
		        	valueForPrintInteger = (int) xxx   ;
		        	System_printf("case 5 ->  time consumed By core -> %d %d   \n",coreNum, valueForPrintInteger );
					        }



			   if (coreNum == 7)
			   {
			    	t1 = TSCL   ;
				    	t1H = TSCH  ;
					  for (loop_filters = 0; loop_filters < NUMBER_OF_FILTERS; loop_filters++)
					  {
				 	     firRealFilter(&inputData[(coreNum * LOOP_8_FIRST)],
			    			         &filterCoef[loop_filters][0], LOOP_8_LAST, FILTER_SIZE,
			    			            &outputFilter[loop_filters][coreNum * LOOP_8_FIRST] ) ;
					  }
				    	t2 = TSCL   ;
				    	t2H = TSCH  ;
				       	diffTime2 = ((float)(t2H - t1H)) * 0x0100000000 + (float)(t2-t1)    ;
				        	xxx = diffTime2 - diffTime1   ;
				        	valueForPrintInteger = (int) xxx   ;
				        	System_printf("case 5 ->  time consumed By core -> %d %d   \n",coreNum, valueForPrintInteger );
			  }


				CACHE_wbInvAllL1dWait() ;
				CACHE_wbInvL2Wait() ;


	#endif




}


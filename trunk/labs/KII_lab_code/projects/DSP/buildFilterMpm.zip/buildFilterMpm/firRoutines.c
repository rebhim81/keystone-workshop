

#include "firTest.h"






void	 generateRandomFloatData(float *pp1, int N, float x_min, float x_max)
{
/****************************************************************************
 * generating random data generates data between min and max
 * The algorithm is the following
 * interval is max-min
 * First we generate random integer sequence between 0 and RAND_MAX and convert it to float
 * Then we multiply each value by interval/(float) RAND_MAX
 * And finally we subtract inteval/2 from each value
 * The result is a sequence of floating point values uniformly distributed between max and min
 *
 *
 *
 */
	float interval   ;
	float interval_over_2  ;
	float x,y_multiply ;
	int  i,j   ;
	interval = x_max - x_min ;
	if (interval < 0) exit(0)   ;
	interval_over_2 = interval * 0.5 ;
	y_multiply = interval / ( (float) RAND_MAX) ;

	for (i=0; i<N;i++)
	{
		j = rand()    ;
		x = (float) j   ;
		*pp1++ = x * y_multiply - interval_over_2   ;

	}


}













void	 generateLimitedSumRandomFloatData(float *pp1, int N, float x_sum)
{
/****************************************************************************
 * generating positive random values so the sum is x_sum
 * The algorithm is the following
 *
 * First we generate random integer sequence between 0 and RAND_MAX and convert it to float
 * then all the numbers are sum into sum1
 * Then we multiply each value by x_sum/sum1
 *
 * The result is a sequence of positive floating point values uniformly distributed with sum x_sum
 * Note - the number of elements is less than MAX_FILETR_SIZE
 *
 *
 *
 */
	float vec[FILTER_SIZE] ;
	float x,y_multiply , sum1;
	int  i,j   ;
	sum1 = 0.0   ; ;
	if (N > FILTER_SIZE ) exit(0)   ;



	for (i=0; i<N;i++)
	{
		j = rand()    ;
		x = (float) j   ;
        vec[i] = x   ;
        sum1 = sum1 + x   ;

	}
	y_multiply = x_sum / sum1 ;
	for (i=0; i<N;i++)
	{
		*pp1++ = vec[i] * y_multiply   ;

	}

}



void firRealFilter(float * in, float * coef,int N, int filterSize, float * output )
{
	int  i,j   ;
	float sum1   ;
	float *p1, *p2   ;
	float *p_coef  ;
	p1 = (float *) in   ;
//#pragma MUST_ITERATE(64,,1);
	for (i=0; i<N;i++)
	{
	   p2 = (float *) p1  ;
	   p1++    ;
	   p_coef = (float *) coef ;
	   sum1 = 0.0   ;
//#pragma MUST_ITERATE(4,,4);
	   for (j=0; j < filterSize; j++)
	   {
		   sum1 = sum1 + *p2++ * *p_coef++  ;  //   myMultiply(*p2++, *p_coef++)    ;
	   }
	   *output++ = sum1   ;
	}




}








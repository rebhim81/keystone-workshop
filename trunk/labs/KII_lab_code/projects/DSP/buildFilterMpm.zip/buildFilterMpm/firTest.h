/*
 * test.h
 *
 *  Created on: October 14, 2013
 *      Author: a0270985
 */

#ifndef FIR_TEST_H_
#define FIR_TEST_H_

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <time.h>

#include <stdio.h>
#include "c6x.h"

#include "utilities.h"

#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <string.h>



#define  NUMBER_OF_ELEMENTS        16384
#define  NUMBER_OF_FILTERS        (16)
#define  FILTER_SIZE              8
#define  MAX_FILETR_SIZE          4098



#define  OUTPUT_VECTOR_SIZE     (NUMBER_OF_ELEMENTS - FILTER_SIZE +1 )
#define  NUMBER_OF_CASES         (5)


#define  LOOP_1_FIRST           (NUMBER_OF_ELEMENTS)
#define  LOOP_1_LAST            (OUTPUT_VECTOR_SIZE - LOOP_1_FIRST * 0  )

#define  LOOP_2_FIRST           (NUMBER_OF_ELEMENTS/2)
#define  LOOP_2_LAST            (OUTPUT_VECTOR_SIZE - LOOP_2_FIRST * 1  )


#define  LOOP_4_FIRST           (NUMBER_OF_ELEMENTS/4)
#define  LOOP_4_LAST            (OUTPUT_VECTOR_SIZE - LOOP_4_FIRST * 3  )


#define  LOOP_8_FIRST           (NUMBER_OF_ELEMENTS/8)
#define  LOOP_8_LAST            (OUTPUT_VECTOR_SIZE - LOOP_8_FIRST * 7  )

#define  MAX_INPUT   128.0
#define  MIN_INPUT  -128.0
#define  FILTER_SUM  1.0





extern void	 generateRandomFloatData(float *pp1, int N, float x_min, float x_max)  ;
extern void	 generateLimitedSumRandomFloatData(float *pp1, int N, float x_sum)  ;

extern void firRealFilter(float *in, float *coef,int N, int filterSize, float *output ) ;


extern float   myMultiply(float x, float  y)   ;




#endif /* FIR_TEST_H_ */
